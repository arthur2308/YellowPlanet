package com.something.yellowplanet;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.ContactsContract;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by new user on 5/25/2016.
 * CLASS USED TO CHECK IF NEW DATA IS ANOMOLOUS WITH PREVIOUSLY COLLECTED DATA
 * GET'S INFO FROM DB AND THEN PIPES IT INTO KMEANS
 *
 */

public class AnomolyChecker {

    final int TIME_MARGIN = 1; //ammount of time slices to get before and after current slice
                              //one time slice = 5 min

    final double ANOMOLY_THRESHOLD = 1; //ammount of distance between centroid and new point to be considered anomoly

    private SQLiteDatabase reader;

    public AnomolyChecker(SQLiteDatabase newReader)
    {
        reader = newReader;
    }


    /*---------------------check for anomoly ---------------------------------------------------
        Checks to see if new x, y feature pair is anomolous among previously recorded results
        returns true if anomoly detected, false otherwise
     */
    public boolean checkForAnomoly(String xFeatureName, double xFeatureVal, String yFeatureName,
                                   double yFeatureVal, int timeSlice)
    {
        double[] xVals = getAllTimeSliceFeatures(timeSlice, xFeatureName);
        double[] yVals = getAllTimeSliceFeatures(timeSlice, yFeatureName);
        List<Point> previousPoints = new ArrayList<Point>();
        for(int i = 0; i < xVals.length; i++) //assume x and y vals have same ammount of data
        {
            previousPoints.add(new Point(xVals[i], yVals[i]));
        }
        KMeans kmeans = new KMeans();
        kmeans.init(previousPoints);
        Point centroidPoint = kmeans.calculate();
        Point newPoint = new Point(xFeatureVal, yFeatureVal);
        double newFeaturesDistance = Point.distance(newPoint,centroidPoint);
        double threshX = centroidPoint.getX() + (centroidPoint.getX() * ANOMOLY_THRESHOLD);
        double threshY = centroidPoint.getY() +  (centroidPoint.getY() * ANOMOLY_THRESHOLD);
        double threshDistance = Point.distance(new Point(threshX,threshY),centroidPoint);
        if(newFeaturesDistance > threshDistance)
        {
            return(true);
        }
        else
        {
            return(false);
        }
    }

    /*----------------------Get all time slice features----------------------------------------
        Querys database for all features enteries of a particular collumn that happened durring a
        particular timeSlice
     */
    private double[] getAllTimeSliceFeatures(int timeslice, String featureName)
    {
        String getFeatureQuery = "select " + featureName + " from " + Storage.DataEntry.TABLE_NAME
                                + " where " + Storage.DataEntry.COL_TIMESLICE + ">=" + (timeslice - TIME_MARGIN)
                                + " AND " + Storage.DataEntry.COL_TIMESLICE + "<=" + (timeslice + TIME_MARGIN);
        Cursor resultsCursor =  reader.rawQuery(getFeatureQuery,null);
        int collumnNum = resultsCursor.getColumnIndex(featureName);
        List<Double> retList = new ArrayList<Double>();
        if(resultsCursor.moveToNext())
        {
            do {
                retList.add(resultsCursor.getDouble(collumnNum));
            }while(resultsCursor.moveToNext());
        }
        double[] retArray = new double[retList.size()];
        for(int i = 0; i < retList.size(); i++)
        {
            retArray[i] = (double)retList.get(i);
        }
        return(retArray);
    }

}
