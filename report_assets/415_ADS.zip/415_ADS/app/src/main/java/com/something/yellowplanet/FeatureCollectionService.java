package com.something.yellowplanet;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;

import java.io.Console;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by new user on 5/19/2016.
 */

public class FeatureCollectionService
{
    final String[][] ALL_FEATURES = {{"battery", "cpu","memory","cpu","netin", "netout"}, //array 0 is feature names
                                    {"default", "default","defualt","default", "default", "default"}}; //array 1 is arguments
                                                                                                    //put arrays in duo's
    final int TIMER_SECONDS = 60000;
    final long MILISECONDS_IN_DAY = 86400000;
    final long NUM_DAYS_TO_KEEP_DATA = 12; //needs to be long so that when multiplied isnt converted to int
    final long NUM_DAYS_FOR_PROFILE_CREATION = 1;

    private featureExtractor features;
    private Timer stopWatch;
    private Context contextToUse;
    private Storage.StorageHelper mainStorage;
    private Storage.StorageHelper averages;
    private SQLiteDatabase writeable;
    private SQLiteDatabase readable;
    private AnomolyChecker anomolyCheck;

    public FeatureCollectionService(Context newContext)
    {
        features = new featureExtractor(newContext);
        stopWatch = new Timer("featureTimer");
        Storage enclosing = new Storage();
        mainStorage = enclosing.new StorageHelper(newContext);
        averages = enclosing.new StorageHelper(newContext);
        writeable = mainStorage.getWritableDatabase();
        readable = mainStorage.getReadableDatabase();
        writeable.execSQL("drop table " + Storage.DataEntry.TABLE_NAME + ";"); //drops table on restart for testing purposes
        mainStorage.onCreate(writeable);
        anomolyCheck = new AnomolyChecker(readable);
        contextToUse = newContext;
    }


    /*------------------------------start collection-----------------------------------------
        Collects system resources every time slice
        Checks for anomalys once resource collection is completed
     */
    public void startCollection()
    {
        TimerTask collectDataTask = new TimerTask() {
            @Override
            public void run() {
                try {
                    long currentMills = System.currentTimeMillis();
                    boolean outOfProfileCreationTime = isOutOfProfileCreation(currentMills);
                    int timeSlice = calculateTimeSlice(currentMills);
                    double[] dataResults = getAllFeatures();
                    boolean anomolyDetected = false;
                    List<String> insertedFeatureNames = new ArrayList<String>(); //keeps all feature names to ensure no duplicates
                    String sqlInsertCommand = "Insert into " + Storage.DataEntry.TABLE_NAME +
                                            " values(" + currentMills + "," + timeSlice + ",";
                    for(int i = 0; i < ALL_FEATURES[0].length; i+= 2)
                    {
                        String xFeatureName = ALL_FEATURES[0][i];
                        double xFeatureVal = dataResults[i];
                        String yFeatureName = ALL_FEATURES[0][i + 1];
                        double yFeatureVal = dataResults[i + 1];
                        if(outOfProfileCreationTime == true) { //doens't check for anomolys till profile created
                            anomolyDetected = anomolyCheck.checkForAnomoly(xFeatureName, xFeatureVal,
                                    yFeatureName, yFeatureVal, timeSlice);
                        }
                        if(anomolyDetected == true)
                        {
                            break; //detected that this batch of data is anomaly, so no need to keep checking
                        }
                        if(insertedFeatureNames.contains(xFeatureName) != true)
                        {
                            sqlInsertCommand += xFeatureVal + ",";
                            insertedFeatureNames.add(xFeatureName);
                        }
                        if(insertedFeatureNames.contains(yFeatureName) != true)
                        {
                            sqlInsertCommand += yFeatureVal;
                            insertedFeatureNames.add(yFeatureName);
                            if(i + 1 != (ALL_FEATURES[0].length - 1))
                            {
                                sqlInsertCommand += ",";
                            }
                        }
                    }
                    if(anomolyDetected == true) //start warning
                    {
                        Intent intent = new Intent(contextToUse, WarningActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        contextToUse.startActivity(intent);
                    }
                    else { //add data to profile
                        sqlInsertCommand += ");";
                        writeable.execSQL(sqlInsertCommand);
                    }
                    cleanOutDatedEnteries(currentMills);
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        };
        stopWatch.scheduleAtFixedRate(collectDataTask,TIMER_SECONDS,TIMER_SECONDS);
    }

    /*------------------------get all features-------------------------------------
        Retrieves the values for the features in allFeatures
        returns an double array with the values in the same order as the allFeatures list
     */
    private double[] getAllFeatures() throws Exception
    {
        double[] retArray = new double[ALL_FEATURES[0].length];
        for(int i = 0; i < ALL_FEATURES[0].length; i++)
        {
            String featureName = ALL_FEATURES[0][i];
            String featureArgs = ALL_FEATURES[1][i];
            double featureVal = features.getFeature(featureName, featureArgs);
            retArray[i] = featureVal;
        }
        return(retArray);
    }

    /*-------------------------clean out dated enteries
        Checks all enteries in db and deletes them if they are older than NUM_DAYS_TO_KEEP_DATA
     */
    private void cleanOutDatedEnteries(long currentMills)
    {
        long threshOld = currentMills - (MILISECONDS_IN_DAY * NUM_DAYS_TO_KEEP_DATA);
        String cleanString = "delete from " + Storage.DataEntry.TABLE_NAME + " where "
                            + Storage.DataEntry.COL_TIMESTAMP + "<" + threshOld;
        writeable.execSQL(cleanString);
    }

    private int calculateTimeSlice(Long currentTime)
    {
        return(1);
        /*
        Calendar time = Calendar.getInstance();
        time.setTimeInMillis(currentTime);
        int timeSliceToStart = (time.get(Calendar.HOUR_OF_DAY)) * 12;
        int sliceToAdd = time.get(Calendar.MINUTE) / 5;
        return(timeSliceToStart + sliceToAdd);
        */
    }

    /*----------------------------get most dated time stamp -------------------------------
        quiries the SQL database to find the most dated entry and returns it
     */
    private long getMostDatedTimeStamp(Long currentMills)
    {
        String getLowest = "select min(" + Storage.DataEntry.COL_TIMESTAMP + ") from "
                           + Storage.DataEntry.TABLE_NAME;
        Cursor newCursor = readable.rawQuery(getLowest, null);
        if(newCursor.moveToNext())
        {
            long retVal = newCursor.getLong(0);
            if(retVal == 0)
            {
                return(currentMills);
            }
            else {
                return (newCursor.getLong(0));
            }
        }
        else
        {
            return(currentMills);
        }
    }

    /*----------------------is out of profile creation-----------------------------------
        Checks if the most dated entry is passed the profile creation time speicified in constants
     */
    private boolean isOutOfProfileCreation(Long currentMills)
    {
        Long mostDated = getMostDatedTimeStamp(currentMills);
        Long compareTime = mostDated + (MILISECONDS_IN_DAY * NUM_DAYS_FOR_PROFILE_CREATION);
        if(currentMills > compareTime)
        {
            return(true);
        }
        else
        {
            return(false);
        }
    }


}
